import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { BmController } from './bm/bm.controller';
import { BmService } from './bm/bm.service';
import { BmModule } from './bm/bm.module';

@Module({
  imports: [BmModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

