export class BmBm {
    readonly description: string;
    readonly isDone: boolean;
}