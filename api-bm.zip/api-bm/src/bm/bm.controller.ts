import { Controller, Post, Req } from '@nestjs/common';
import { METHODS } from 'http';

export interface BmBm{
    readonly description: string;
    readonly isDone: boolean;
}
@Controller('api/v1/bm')
export class BmController {
    @Post()
    METHODS(@Req() req: Request): string {
        return 'method ${req.method}';
    }
    }